# tripilot-model-qwen

Optional local Qwen3-0.6B Q4_K_M for TriPilot. This small manifest package depends on five data packages and tripilot-runtime. npm installs all payloads; there are no lifecycle scripts or external artifact downloads. TriPilot streams and verifies each part, reconstructs the original 397 MB GGUF locally and checks its full SHA-256 before use. Total model transfer is about 386 MB plus the runtime.

Install `pnpm add -D tripilot-e2e@alpha tripilot-model-qwen@alpha`, then `pnpm exec tripilot ai-prepare --offline`. Do not import these development-host tools into the mobile app. See provenance.json, LICENSE and NOTICE.
